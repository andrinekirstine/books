package inheritance;

public class DebitAccount extends AbstractAccount {
	
	@Override
	void internalWithdraw(double amount) {
		if (amount > balance) {
			throw new IllegalStateException("You can not withdraw more money than you got.");
		}
		balance -= amount;
	}

}
