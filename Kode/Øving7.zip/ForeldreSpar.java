package inheritance;

public class ForeldreSpar extends SavingsAccount implements Account {
	private final int legalWithdraws;
	private int w = 0;
	
	
	public ForeldreSpar(double interest, int legalWithdraws) {
		super(interest);
		this.legalWithdraws = legalWithdraws;
	}
	
	@Override
	public void withdraw(double amount) {
		if (w >= legalWithdraws) {
			throw new IllegalStateException("You can not withdraw, because you have reached the limit.");
		}
		super.withdraw(amount);
		w += 1;
	}
	
	
	public int getRemainingWithdrawals() {
		return legalWithdraws - w;
	}

	@Override
	public void endYearUpdate() {
		super.endYearUpdate();
		w = 0;
	}
	
	
	
}
