package inheritance;

public class BSU extends SavingsAccount implements Account {
	final double limit;
	double yearlyBalance;
	double taxDeduction;
	
	
	public BSU(double interest, double limit) {
		super(interest);
		this.limit = limit;
		}
	
	public double depositLimit() {
		return limit - yearlyBalance;
	}
	
	public double getTaxDeduction() {
		taxDeduction = yearlyBalance * 0.2;
		return taxDeduction;
	}
	
	
	@Override
	public void deposit(double amount) {
		if (amount > depositLimit()) {
			throw new IllegalStateException("You can not depost more than the yearly limit.");
		}
		yearlyBalance += amount;
		super.deposit(amount);
	}
	
	
	@Override
	public void withdraw(double amount) {
		if (yearlyBalance < amount) {
			throw new IllegalStateException("A withdraw can not be bigger than the amout on the account.");
		}
		yearlyBalance -= amount;
		super.withdraw(amount);
	}
	
	@Override
	public void endYearUpdate() {
		super.endYearUpdate();
		yearlyBalance = 0;
	}
}
