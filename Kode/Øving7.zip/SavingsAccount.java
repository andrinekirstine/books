package inheritance;

public class SavingsAccount implements Account {
	protected double balance;
	protected double interest;

	public SavingsAccount(double interest) {
		balance = 0;
		if (interest < 0) {
			throw new IllegalArgumentException("The interest can not be negativ or 0.");
		}
		this.interest = interest;
	}
	
	
	@Override
	public void deposit(double amount) {
		// TODO Auto-generated method stub
		if (amount <= 0) {
			throw new IllegalArgumentException("A deposit can not be negativ or 0.");
		}
		balance += amount;
	}

	@Override
	public void withdraw(double amount) {
		// TODO Auto-generated method stub
		if (amount <= 0) {
			throw new IllegalArgumentException("A withdraw can not be negativ or 0.");
		}
		if (balance < amount) {
			throw new IllegalStateException("A withdraw can not be bigger than the amout on the account.");
		}
		balance -= amount;
	}

	@Override
	public double getBalance() {
		// TODO Auto-generated method stub
		return balance;
	}
	
	public void endYearUpdate() {
		balance += interest * balance;
	}
}

