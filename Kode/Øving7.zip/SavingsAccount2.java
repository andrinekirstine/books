package inheritance;

public class SavingsAccount2 extends AbstractAccount {
	private double fee;
	private int legalWithdrawals;
	private int a = 0;
	
	public SavingsAccount2(int legalWithdrawals, double fee) {
		if (fee < 0) {
			throw new IllegalArgumentException("Du kan ikke skylde negative penger.");
		}
		if (legalWithdrawals < 0) {
			throw new IllegalArgumentException("Du kan ikke ikke kunne ta ut penger negativt antall ganger.");
		}
		this.fee = fee;
		this.legalWithdrawals = legalWithdrawals;
	}
	
	
	@Override
	void internalWithdraw(double amount) {
		if (amount > balance) {
			throw new IllegalStateException("No. Just no.");
		}
		if (a >= legalWithdrawals) {
			if (amount + fee > balance) {
				throw new IllegalStateException("Com'on.");
			}
			balance -= amount + fee;
		}
		else {
			balance -= amount;
		}
		a += 1;
	}
	
}
