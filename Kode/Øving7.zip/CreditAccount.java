package inheritance;

public class CreditAccount extends AbstractAccount {
	private double creditLine;
	
	public CreditAccount(double creditLine) {
		if (creditLine < 0) {
			throw new IllegalArgumentException("Du kan ikke ha antigjeld.");
		}
		this.creditLine = creditLine;
	}
	
	@Override
	void internalWithdraw(double amount) {
		if (amount > creditLine + balance) {
			throw new IllegalStateException("Du har ikke s� mye penger.");
		}
		balance -= amount;
	}

	public double getCreditLine() {
		return creditLine;
	}
	
	
	public void setCreditLine(double creditLine) {
		if (creditLine < 0) {
			throw new IllegalArgumentException("Du kan ikke ha antigjeld.");
		}
		if (creditLine < -balance) {
			throw new IllegalStateException("Du kan ikke ha mindre gjeld enn det du har.");
		}
		this.creditLine = creditLine;
	}
	
}
