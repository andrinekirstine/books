package stateandbehavior;


public class Account {
	double balance;
	double interestRate;
	
	
	public void deposit(double value) {
		if (value > 0) {
			balance += value;
		} 
	}
	public void addInterest() {
		balance += balance * interestRate / 100;
	}

	public double getBalance() {
		return balance;
	}

	public double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(double rate) {
		if (rate >= 0) {
			interestRate = rate;
		}
	}


	public String toString() {
		String a = new String();
		a += "balance: " + getBalance().toString();
		a += "\ninterestRate: "+  getInterestRate().toString();
		return a;
	}

	public static void main(String[] args) {
		Account hansen = new Account();
		hansen.setInterestRate(1.3);
		System.out.println(hansen.toString());
		hansen.deposit(100);
		System.out.println(hansen.toString());
		System.out.println(hansen.getBalance());
		System.out.println(hansen.getInterestRate());
		hansen.addInterest();
		System.out.println(hansen.toString());
		System.out.println(hansen.getBalance());
		hansen.setInterestRate(1.8);
		System.out.println(hansen.toString());
	}

}
