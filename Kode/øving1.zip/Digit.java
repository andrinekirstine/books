package stateandbehavior;

public class Digit {
    
    int radix;
    int value;

    public Digit(int radix){
        this.radix = radix;
        value = 0;
    }

    public int getValue() {
        return value;
    }

    public boolean increment() {
        value++;
       
        if (value >= radix){
            value = 0;
            return true; 
        } 
        
        else {
            return false;
        }
    }

    public int getBase() {
        return radix;
    }

    public String toString() {
        return Integer.toString(value, radix);
    }

    public static void main(String[] args) {
        Digit tall = new Digit(11);
        tall.increment();
        System.out.println(tall.toString());
        tall.increment();
        System.out.println(tall.toString());
        tall.increment();
        System.out.println(tall.toString());
        tall.increment();
        System.out.println(tall.toString());
        tall.increment();
        System.out.println(tall.toString());
        tall.increment();
        System.out.println(tall.toString());
        System.out.println(tall.getValue());
        tall.increment();
        System.out.println(tall.toString());
        System.out.println(tall.getBase());
        tall.increment();
        System.out.println(tall.toString());
        tall.increment();
        System.out.println(tall.toString());
        tall.increment();
        System.out.println(tall.toString());
        tall.increment();
        System.out.println(tall.toString());
    }







}

