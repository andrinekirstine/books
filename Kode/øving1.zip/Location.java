package stateandbehavior;

public class Location {
    int x; 
    int y;

    public void up() {
        y--;
    }

    public void down() {
        y++;
    }

    public void left() {
        x--;
    }

    public void right() {
        x++;
    }

    public int getX() {
        return x;
    }
    
    public int getY() {
        return y;
    }

    public String toString() {
        return "(x, y): " + x.toString() + ", " + y.toString() ;
    }

    public static void main(String[] args) {
        Location pos = new Location();
        System.out.println(pos.toString());
        pos.up();
        System.out.println(pos.toString());
        pos.right();
        System.out.println(pos.toString());
        pos.down();
        System.out.println(pos.toString());
        pos.down();
        System.out.println(pos.toString());
        pos.left();
        System.out.println(pos.toString());
        pos.left();
        System.out.println(pos.toString());
    }
}