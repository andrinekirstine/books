package interfaces.twitter;

import java.util.Collections;
import java.util.Comparator;
import java.util.ArrayList;

public class TwitterAccount {
	private String username;
	private ArrayList<TwitterAccount> followers;
	private ArrayList<TwitterAccount> following;
	private ArrayList<Tweet> tweets; 
	
	
	public TwitterAccount(String username) {
		this.username = username;
		followers = new ArrayList<TwitterAccount>();
		following = new ArrayList<TwitterAccount>();
		tweets = new ArrayList<Tweet>();
	}
	
	public String getUserName() {
		return username;
	}
	
	public void follow(TwitterAccount account) {
		this.following.add(account);
		account.followers.add(this);
	}

	public void unfollow(TwitterAccount account) {
		this.following.remove(account);
		account.followers.remove(this);
	}
	
	public boolean isFollowing(TwitterAccount account) {
		return this.following.contains(account);
	}
	
	public boolean isFollowedBy(TwitterAccount account) {
		return account.isFollowing(this);
	}
	
	public int getFollowersCount() {
		return this.followers.size(); 
	}
	
	public void tweet(String txt) {
		this.tweets.add(new Tweet(this, txt)) ;
	}
	
	public void retweet(Tweet tweet) {
		this.tweets.add(new Tweet(this, tweet)) ;
	}

	public Tweet getTweet(int i) {
		return this.tweets.get(this.tweets.size()-i);
	}
	
	public int getTweetCount() {
		return this.tweets.size();
	}

	public int getRetweetCount() {
		int sum = 0;
		for (Tweet t: tweets) {
			sum += t.getRetweetCount();
		}
		return sum;
	}
	
	public ArrayList<TwitterAccount> getFollowers(Comparator<TwitterAccount> c) {
		ArrayList<TwitterAccount> f = (ArrayList<TwitterAccount>) followers.clone();
		if (c == null) {
			return f;
		}
		Collections.sort(f, c);
		
		return f;
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
