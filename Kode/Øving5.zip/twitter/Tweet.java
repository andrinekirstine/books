package interfaces.twitter;

public class Tweet {
	private TwitterAccount tacc;
	private String txt; 
	private int a;
	private Tweet originalTweet; 
	
	public Tweet(TwitterAccount tacc, String txt) {
		this.tacc = tacc;
		this.txt = txt;
		a = 0;
		originalTweet = null; 
	}
	
	public Tweet(TwitterAccount tacc, Tweet tweet) {
		if (tacc == tweet.getOwner()) {
			throw new IllegalArgumentException("You can not retweet your own tweet.");
		}
		a = 0;
		this.tacc = tacc;
		this.txt = tweet.getText();
		if (tweet.getOriginalTweet() == null) {
			originalTweet = tweet;
		}
		else {
			this.originalTweet = tweet.getOriginalTweet();
		}
		this.originalTweet.increaseRetweetCount();
	}
	
	public TwitterAccount getOwner() {
		return tacc;
	}
	
	public String getText() {
		return txt;
	}
	
	private void increaseRetweetCount() {
		a += 1;
	}
	
	public int getRetweetCount() {
		return a;
	}
	
	public Tweet getOriginalTweet() {
		return originalTweet;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
