package interfaces;

public class Person2 implements Named {
	private String fullName;
	
	public Person2(String fullName) {
		setFullName(fullName);
	}
	
	
	@Override
	public void setGivenName(String newName) {
		// TODO Auto-generated method stub
		setFullName(newName + " " + getFamilyName());
	}

	@Override
	public String getGivenName() {
		// TODO Auto-generated method stub
		return fullName.split(" ")[0];
	}

	@Override
	public void setFamilyName(String familyName) {
		// TODO Auto-generated method stub
		setFullName(getGivenName() + " " + familyName);
	}

	@Override
	public String getFamilyName() {
		// TODO Auto-generated method stub
		return fullName.split(" ")[1];
	}

	@Override
	public void setFullName(String fullName) {
		// TODO Auto-generated method stub
		this.fullName = fullName;
	}

	@Override
	public String getFullName() {
		// TODO Auto-generated method stub
		return fullName;
	}

}
