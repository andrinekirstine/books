package interfaces;

import java.util.ArrayList;
import java.util.Comparator;

public class NamedComparator implements Comparator<Named> {

	
	
	@Override
	public int compare(Named o1, Named o2) {
		// TODO Auto-generated method stub
		int a = o1.getFamilyName().compareTo(o2.getFamilyName());
		if (a == 0) {
			return o1.getGivenName().compareTo(o2.getGivenName());
		}
		return a;

	}
	public static void main(String[] args) {
		ArrayList<Named> l = new ArrayList<Named>() ;
		l.add(new Person1("Bente", "Bent"));
		l.add(new Person2("Katja Kai"));
		l.add(new Person1("Arne", "Bent"));
		l.add(new Person2("Kaja Kai"));
		NamedComparator c = new NamedComparator();
		System.out.println(l);
		l.sort(c);
		System.out.println(l);
	}
}

	