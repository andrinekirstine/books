package interfaces;

public class Person1 implements Named {
	private String givenName;
	private String familyName;	
	
	
	public Person1(String givenName, String familyName) {
		setGivenName(givenName);
		setFamilyName(familyName);
	}
	
	
	@Override
	public void setGivenName(String newName) {
		// TODO Auto-generated method stub
		givenName = newName;
	}

	@Override
	public String getGivenName() {
		// TODO Auto-generated method stub
		return givenName;
	}

	@Override
	public void setFamilyName(String familyName) {
		// TODO Auto-generated method stub
		this.familyName = familyName;
	}

	@Override
	public String getFamilyName() {
		// TODO Auto-generated method stub
		return familyName;
	}

	@Override
	public void setFullName(String fullName) {
		// TODO Auto-generated method stub
		String[] splittedName = fullName.split(" ");
		setGivenName(splittedName[0]);
		setFamilyName(splittedName[1]);
	}

	@Override
	public String getFullName() {
		// TODO Auto-generated method stub
		return givenName + " " + familyName;
	}

}
